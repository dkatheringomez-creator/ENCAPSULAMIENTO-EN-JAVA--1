
/**
 * Clase principal para demostrar la clase Temperatura y sus restricciones.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("===== EJERCICIO 2: TEMPERATURA EN JAVA =====\n");

        Temperatura ambiente = new Temperatura(20.0);
        System.out.println("1. Temperatura inicial:");
        ambiente.mostrarTemperatura();

        System.out.println("\n2. Aumentando la temperatura en 5 °C:");
        ambiente.aumentar(5.0);
        ambiente.mostrarTemperatura();

        System.out.println("\n3. Disminuyendo la temperatura en 10 °C:");
        ambiente.disminuir(10.0);
        ambiente.mostrarTemperatura();

        System.out.println("\n4. Intentando disminuir la temperatura más allá del cero absoluto:");
        ambiente.disminuir(300.0);
        ambiente.mostrarTemperatura();

        System.out.println("\n5. Creando otra temperatura inicial menor al cero absoluto:");
        Temperatura extremo = new Temperatura(-300.0);
        extremo.mostrarTemperatura();

        System.out.println("\n6. Disminuyendo la segunda temperatura en 10 °C:");
        extremo.disminuir(10.0);
        extremo.mostrarTemperatura();

        System.out.println("===== FIN DEL EJERCICIO 2 =====");
    }
}
