
/**
 * Clase Temperatura que implementa encapsulamiento para el valor en grados Celsius.
 * Se asegura de que la temperatura no baje del cero absoluto (-273.15 °C).
 */
public class Temperatura {

    // Atributo privado
    private double celsius;

    /**
     * Constructor de la clase Temperatura.
     *
     * @param celsius Valor inicial de la temperatura en grados Celsius.
     */
    public Temperatura(double celsius) {
        if (celsius < -273.15) {
            System.out.println("Advertencia: la temperatura no puede ser menor al cero absoluto. Se asigna -273.15 °C.");
            this.celsius = -273.15;
        } else {
            this.celsius = celsius;
        }
    }

    /**
     * Muestra el valor actual de la temperatura.
     */
    public void mostrarTemperatura() {
        System.out.printf("Temperatura actual: %.2f °C%n", this.celsius);
    }

    /**
     * Aumenta la temperatura en una cantidad dada.
     *
     * @param incremento Valor a sumar en grados Celsius.
     */
    public void aumentar(double incremento) {
        this.celsius += incremento;
        System.out.printf("Aumentando temperatura en %.2f °C. Nuevo valor: %.2f °C%n", incremento, this.celsius);
    }

    /**
     * Disminuye la temperatura en una cantidad dada, sin bajar del cero
     * absoluto.
     *
     * @param decremento Valor a restar en grados Celsius.
     */
    public void disminuir(double decremento) {
        double nuevoValor = this.celsius - decremento;
        if (nuevoValor < -273.15) {
            System.out.println("ERROR: La temperatura no puede bajar del cero absoluto (-273.15 °C).");
            System.out.printf("Intento realizado: %.2f °C. Valor actual permanece en %.2f °C.%n", nuevoValor, this.celsius);
        } else {
            this.celsius = nuevoValor;
            System.out.printf("Disminuyendo temperatura en %.2f °C. Nuevo valor: %.2f °C%n", decremento, this.celsius);
        }
    }

    // Getter accesible para el valor de la temperatura
    public double getCelsius() {
        return this.celsius;
    }
}
