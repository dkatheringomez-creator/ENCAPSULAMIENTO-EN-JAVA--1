
/**
 * Clase principal para demostrar el comportamiento de la clase Vehiculo.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("===== EJERCICIO 4: VEHICULO EN JAVA =====\n");

        Vehiculo miAuto = new Vehiculo("Toyota", "Corolla", 180.0);
        System.out.println("1. Estado inicial del vehiculo:");
        miAuto.mostrarEstado();

        System.out.println("2. Acelerando 50 km/h:");
        miAuto.acelerar(50.0);
        miAuto.mostrarEstado();

        System.out.println("3. Acelerando 150 km/h (supera el limite):");
        miAuto.acelerar(150.0);
        miAuto.mostrarEstado();

        System.out.println("4. Frenando 30 km/h:");
        miAuto.frenar(30.0);
        miAuto.mostrarEstado();

        System.out.println("5. Frenando 200 km/h (intento de velocidad negativa):");
        miAuto.frenar(200.0);
        miAuto.mostrarEstado();

        System.out.println("6. Intentando acelerar con un valor negativo:");
        miAuto.acelerar(-20.0);
        miAuto.mostrarEstado();

        System.out.println("7. Intentando frenar con un valor negativo:");
        miAuto.frenar(-10.0);
        miAuto.mostrarEstado();

        System.out.println("===== FIN DEL EJERCICIO 4 =====");
    }
}
