
/**
 * Clase Vehiculo que implementa encapsulamiento para marca, modelo y velocidad.
 * Controla la velocidad sin permitir valores negativos ni superar el límite máximo.
 */
public class Vehiculo {

    private String marca;
    private String modelo;
    private double velocidad;
    private double velocidadMaxima;

    /**
     * Constructor de la clase Vehiculo.
     *
     * @param marca Marca del vehiculo.
     * @param modelo Modelo del vehiculo.
     * @param velocidadMaxima Limite maximo de velocidad.
     */
    public Vehiculo(String marca, String modelo, double velocidadMaxima) {
        this.marca = marca;
        this.modelo = modelo;
        this.velocidad = 0.0;
        if (velocidadMaxima <= 0) {
            System.out.println("Advertencia: la velocidad máxima debe ser mayor que 0. Se asigna 200.0.");
            this.velocidadMaxima = 200.0;
        } else {
            this.velocidadMaxima = velocidadMaxima;
        }
    }

    /**
     * Aumenta la velocidad del vehiculo hasta el limite maximo.
     *
     * @param incremento Kilometros por hora a sumar.
     */
    public void acelerar(double incremento) {
        if (incremento < 0) {
            System.out.println("ERROR: El incremento de velocidad no puede ser negativo.");
            return;
        }
        double nuevaVelocidad = this.velocidad + incremento;
        if (nuevaVelocidad > this.velocidadMaxima) {
            System.out.printf("La velocidad no puede superar el limite de %.2f km/h. Se ajusta al maximo.%n", this.velocidadMaxima);
            this.velocidad = this.velocidadMaxima;
        } else {
            this.velocidad = nuevaVelocidad;
            System.out.printf("Acelerando %.2f km/h. Velocidad actual: %.2f km/h.%n", incremento, this.velocidad);
        }
    }

    /**
     * Reduce la velocidad del vehículo sin permitir valores negativos.
     *
     * @param decremento Kilómetros por hora a restar.
     */
    public void frenar(double decremento) {
        if (decremento < 0) {
            System.out.println("ERROR: El decremento de velocidad no puede ser negativo.");
            return;
        }
        double nuevaVelocidad = this.velocidad - decremento;
        if (nuevaVelocidad < 0) {
            System.out.println("La velocidad no puede ser negativa. Se detiene el vehiculo.");
            this.velocidad = 0.0;
        } else {
            this.velocidad = nuevaVelocidad;
            System.out.printf("Frenando %.2f km/h. Velocidad actual: %.2f km/h.%n", decremento, this.velocidad);
        }
    }

    /**
     * Muestra el estado actual del vehículo.
     */
    public void mostrarEstado() {
        System.out.println("\n========== ESTADO DEL VEHICULO ==========");
        System.out.println("Marca: " + this.marca);
        System.out.println("Modelo: " + this.modelo);
        System.out.printf("Velocidad actual: %.2f km/h%n", this.velocidad);
        System.out.printf("Velocidad maxima: %.2f km/h%n", this.velocidadMaxima);
        System.out.println("========================================\n");
    }
}
