/**
 * Clase Principal para demostrar el encapsulamiento de la clase Libro
 */
public class Main {
    
    public static void main(String[] args) {
        System.out.println("===== EJERCICIO 1: ENCAPSULAMIENTO EN JAVA =====\n");
        
        // 1. Crear un objeto de tipo Libro con valores iniciales válidos
        System.out.println("1. Creando un objeto Libro con valores iniciales...");
        Libro libro1 = new Libro("El Quijote", "Miguel de Cervantes", 863);
        
        // 2. Mostrar la información inicial del libro
        System.out.println("2. Mostrando información inicial del libro:");
        libro1.mostrarInformacion();
        
        // 3. Actualizar el número de páginas con un valor válido
        System.out.println("3. Actualizando el número de páginas con un valor válido:");
        if (libro1.actualizarPaginas(900)) {
            System.out.println("Actualización exitosa.\n");
        }
        
        // Mostrar la información actualizada
        System.out.println("4. Información del libro después de la actualización:");
        libro1.mostrarInformacion();
        
        // 4. Intentar asignar un valor inválido (negativo)
        System.out.println("5. Intentando asignar un valor inválido (número negativo):");
        libro1.actualizarPaginas(-50);
        System.out.println();
        
        // Verificar que el valor no cambió
        System.out.println("6. Información del libro luego del intento fallido:");
        libro1.mostrarInformacion();
        
        // 5. Intentar asignar cero (también inválido)
        System.out.println("7. Intentando asignar cero:");
        libro1.actualizarPaginas(0);
        System.out.println();
        
        // Verificar que el valor sigue siendo el anterior
        System.out.println("8. Información final del libro:");
        libro1.mostrarInformacion();
        
        // Crear otro libro para demostrar el encapsulamiento
        System.out.println("9. Creando otro libro con validación en el constructor:");
        Libro libro2 = new Libro("1984", "George Orwell", -200);
        libro2.mostrarInformacion();
        
        // Actualizar libro2 con un valor válido
        System.out.println("10. Actualizando libro2 con un valor válido:");
        libro2.actualizarPaginas(328);
        libro2.mostrarInformacion();
        
        System.out.println("===== FIN DEL EJERCICIO 1 =====");
    }
}
