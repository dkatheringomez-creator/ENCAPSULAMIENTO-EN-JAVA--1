/**
 * Clase Libro que implementa encapsulamiento
 * Atributos privados: título, autor, número de páginas
 */
public class Libro {
    
    // Atributos privados
    private String titulo;
    private String autor;
    private int numeroPaginas;
    
    /**
     * Constructor de la clase Libro
     * @param titulo El título del libro
     * @param autor El autor del libro
     * @param numeroPaginas El número de páginas (debe ser mayor que 0)
     */
    public Libro(String titulo, String autor, int numeroPaginas) {
        this.titulo = titulo;
        this.autor = autor;
        // Validar que el número de páginas sea válido
        if (numeroPaginas > 0) {
            this.numeroPaginas = numeroPaginas;
        } else {
            this.numeroPaginas = 0;
            System.out.println("Advertencia: El número de páginas debe ser mayor que 0. Se asignó 0.");
        }
    }
    
    /**
     * Método público para mostrar la información del libro
     */
    public void mostrarInformacion() {
        System.out.println("\n========== INFORMACIÓN DEL LIBRO ==========");
        System.out.println("Título: " + this.titulo);
        System.out.println("Autor: " + this.autor);
        System.out.println("Número de páginas: " + this.numeroPaginas);
        System.out.println("==========================================\n");
    }
    
    /**
     * Método público para actualizar el número de páginas
     * Valida que el nuevo valor sea mayor que cero
     * @param nuevoPaginas El nuevo número de páginas
     * @return true si la actualización fue exitosa, false si el valor es inválido
     */
    public boolean actualizarPaginas(int nuevoPaginas) {
        if (nuevoPaginas > 0) {
            System.out.println("Actualizando número de páginas de " + this.numeroPaginas + " a " + nuevoPaginas);
            this.numeroPaginas = nuevoPaginas;
            return true;
        } else {
            System.out.println("ERROR: El número de páginas debe ser mayor que 0.");
            System.out.println("No se realizará la actualización. Valor actual: " + this.numeroPaginas);
            return false;
        }
    }
    
    // Getters (métodos accesores)
    public String getTitulo() {
        return this.titulo;
    }
    
    public String getAutor() {
        return this.autor;
    }
    
    public int getNumeroPaginas() {
        return this.numeroPaginas;
    }
    
    // Setters (métodos mutadores) - con validación
    public void setTitulo(String nuevoTitulo) {
        this.titulo = nuevoTitulo;
    }
    
    public void setAutor(String nuevoAutor) {
        this.autor = nuevoAutor;
    }
}
