
/**
 * Clase principal para demostrar el uso de Producto y la validación de precio.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("===== EJERCICIO 3: PRODUCTO EN JAVA =====\n");

        Producto producto = new Producto("Camiseta", 29.99, 50);
        System.out.println("1. Producto inicial:");
        producto.mostrarInformacion();

        System.out.println("2. Actualizando el precio a un valor válido:");
        producto.actualizarPrecio(34.99);
        producto.mostrarInformacion();

        System.out.println("3. Intentando asignar un precio inválido (-10.00):");
        producto.actualizarPrecio(-10.00);
        producto.mostrarInformacion();

        System.out.println("4. Intentando asignar otro precio inválido (-0.01):");
        producto.actualizarPrecio(-0.01);
        producto.mostrarInformacion();

        System.out.println("===== FIN DEL EJERCICIO 3 =====");
    }
}
