
/**
 * Clase Producto que implementa encapsulamiento para los datos de un producto.
 */
public class Producto {

    private String nombre;
    private double precio;
    private int cantidad;

    /**
     * Constructor de Producto.
     *
     * @param nombre Nombre del producto.
     * @param precio Precio del producto.
     * @param cantidad Cantidad disponible en inventario.
     */
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        if (precio < 0) {
            System.out.println("Advertencia: el precio no puede ser negativo. Se asigna 0.0.");
            this.precio = 0.0;
        } else {
            this.precio = precio;
        }
    }

    /**
     * Muestra la información completa del producto.
     */
    public void mostrarInformacion() {
        System.out.println("\n========== INFORMACIÓN DEL PRODUCTO ==========");
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Precio: $" + String.format("%.2f", this.precio));
        System.out.println("Cantidad disponible: " + this.cantidad);
        System.out.println("============================================\n");
    }

    /**
     * Asigna un nuevo precio al producto, validando que no sea negativo.
     *
     * @param nuevoPrecio El nuevo precio a asignar.
     * @return true si el precio se actualiza, false si el valor es inválido.
     */
    public boolean actualizarPrecio(double nuevoPrecio) {
        if (nuevoPrecio < 0) {
            System.out.println("ERROR: El precio no puede ser negativo. No se actualiza.");
            System.out.println("Precio actual: $" + String.format("%.2f", this.precio));
            return false;
        }
        this.precio = nuevoPrecio;
        System.out.println("Precio actualizado a $" + String.format("%.2f", this.precio));
        return true;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }
}
