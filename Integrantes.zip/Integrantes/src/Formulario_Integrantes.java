
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author gomez
 */


public class Formulario_Integrantes extends JFrame implements ActionListener {

    private JButton boton1, boton2, boton3, boton4, boton5, boton6, salir;
    private JLabel label1;

    public Formulario_Integrantes() {
        setLayout(null);

       
        boton1 = new JButton("1");
        boton1.setBounds(10, 100, 60, 30);
        add(boton1);
        boton1.addActionListener(this);

        boton2 = new JButton("2");
        boton2.setBounds(80, 100, 60, 30);
        add(boton2);
        boton2.addActionListener(this);

        boton3 = new JButton("3");
        boton3.setBounds(150, 100, 60, 30);
        add(boton3);
        boton3.addActionListener(this);

        boton4 = new JButton("4");
        boton4.setBounds(220, 100, 60, 30);
        add(boton4);
        boton4.addActionListener(this);

        boton5 = new JButton("5");
        boton5.setBounds(50, 140, 60, 30);
        add(boton5);
        boton5.addActionListener(this);

        boton6 = new JButton("6");
        boton6.setBounds(150, 140, 60, 30);
        add(boton6);
        boton6.addActionListener(this);

        salir = new JButton("Salir");
        salir.setBounds(100, 180, 100, 30);
        add(salir);
        salir.addActionListener(this);

    
        label1 = new JLabel("En espera...");
        label1.setBounds(10, 20, 300, 30);
        add(label1);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == boton1) {
            label1.setText("Danna Gómez");
            JOptionPane.showMessageDialog(this, "Integrante: Danna Gómez");
        }

        if (e.getSource() == boton2) {
            label1.setText("Zaida Morales");
            JOptionPane.showMessageDialog(this, "Integrante: Zaida Morales");
        }

        if (e.getSource() == boton3) {
            label1.setText("David Moreno");
            JOptionPane.showMessageDialog(this, "Integrante: David Moreno");
        }

        if (e.getSource() == boton4) {
            label1.setText("Julián Castellanos");
            JOptionPane.showMessageDialog(this, "Integrante: Julián Castellanos");
        }

        if (e.getSource() == boton5) {
            label1.setText("Cristian Diaz");
            JOptionPane.showMessageDialog(this, "Integrante:Cristian Diaz");
        }

        if (e.getSource() == boton6) {
            label1.setText("Andres Medrano");
            JOptionPane.showMessageDialog(this, "Integrante: Andres Medrano");
        }

        if (e.getSource() == salir) {
            int opcion = JOptionPane.showConfirmDialog(this, "¿Desea salir?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        }
    }


}


    
