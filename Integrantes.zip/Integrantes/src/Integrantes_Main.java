/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author gomez
 */
public class Integrantes_Main {
   public static void main(String args[]) {
        Formulario_Integrantes formulario1 = new Formulario_Integrantes();
        formulario1.setBounds(0, 0, 320, 250);
        formulario1.setVisible(true);
        formulario1.setResizable(false);
        formulario1.setLocationRelativeTo(null);
    }
}